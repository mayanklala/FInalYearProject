from django.apps import AppConfig


class PlagCheckAppConfig(AppConfig):
    name = 'plag_check_app'
